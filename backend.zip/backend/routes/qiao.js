var express = require('express');
var router = express.Router();
require('../moudle/index'); // 确保用户模型被加载
var { Product } = require('../moudle/goods');
/* GET home page. */
// router.get('/products', function (req, res, next) {
//     res.render('index', { title: 'Express' });
// });
// 获取商品列表

// 获取商品列表
router.get('/products', async function (req, res) {
    try {
        const products = await Product.find({}); // 获取全部商品
        console.log(products, '1')
        // MongooseError: Operation `products.find()` buffering timed out after 10000ms  解决

        res.json({ success: true, data: products });
        //     console.log(products, '1')
        //     res.json({ success: true, data: products });
    } catch (err) {

        console.log(err, '2')
    }
});



module.exports = router;
