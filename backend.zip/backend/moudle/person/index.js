// 人员模块所有模型的统一导出文件

const PersonInCharge = require('./personInCharge');

module.exports = {
  PersonInCharge
};