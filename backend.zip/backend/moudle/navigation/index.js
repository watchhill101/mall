// 导航模块所有模型的统一导出文件

const FirstLevelNavigation = require('./firstLevelNavigation');
const SecondaryNavigation = require('./secondaryNavigation');

module.exports = {
  FirstLevelNavigation,
  SecondaryNavigation
};